/**
 * Created by Administrator on 2017/5/16.
 */
const getters = {
  loading: state => state.loading,
  showToast: state => state.showToast,
  showAlert: state => state.showAlert
}
