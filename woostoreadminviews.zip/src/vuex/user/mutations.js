/**
 * Created by Administrator on 2017/5/16.
 */
import * as types from './types'
export default {
  [types.SET_USER_INFO] (state, res) {
    //  alert('SET_USER_INFO')
    state.userInfo = res.data
  },

  [types.SET_LOGIN_STATUS] (state, status) {
    //  alert('SET_LOGIN_STATUS')
    state.loginStatus = status
  },

  [types.GET_USER_DATA] (state, res) {
    //  alert('GET_USER_DATA')
    state.userData = res.data
  },

  [types.SET_LOGINTOKEN] (state, res) {
    //  alert('SET_LOGINTOKEN')
    state.loginToken = res.Authorization
  },
  [types.REMOVE_TOKEN] (state) {
    state.loginToken = ''
  }
}
