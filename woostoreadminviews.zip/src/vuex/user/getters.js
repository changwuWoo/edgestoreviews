/**
 * Created by Administrator on 2017/5/16.
 */
export default {
  getUserData: state => state.userData,
  loginStatus: state => state.loginStatus,
  userInfo: state => state.userInfo,
  loginToken: state => state.loginStatus
}
